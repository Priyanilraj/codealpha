import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

# Download necessary NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

# Define a list of predefined responses
responses = {
    'greeting': "Hello! How can I assist you today?",
    'goodbye': "Goodbye, have a great day!",
    'default': "I'm sorry, I didn't understand that. Could you please rephrase your question?"
}

# Define a function to preprocess user input
def preprocess_input(user_input):
    # Tokenize the input
    tokens = nltk.word_tokenize(user_input.lower())
    
    # Remove stop words
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [word for word in tokens if word not in stop_words]
    
    # Stem the words
    stemmer = PorterStemmer()
    stemmed_tokens = [stemmer.stem(word) for word in filtered_tokens]
    
    return ' '.join(stemmed_tokens)

# Define a function to handle user input and generate a response
def chatbot_response(user_input):
    preprocessed_input = preprocess_input(user_input)
    
    # Check for predefined responses
    if 'hello' in preprocessed_input or 'hi' in preprocessed_input:
     return responses['greeting']
    elif 'bye' in preprocessed_input or 'goodbye' in preprocessed_input:
        return responses['goodbye']
    else:
        return responses['default']

# Run the chatbot
while True:
    user_input = input("User: ")
    response = chatbot_response(user_input)
    print("Chatbot:",response)