import random

# List of words to choose from
words = [ "banana", "apple", "mango", "kiwi", "orange", "pineapple","watermelon", "avocado", "apricot", "blueberry", "guvava","cherry", "papaya", "grapefruit" , "strawberry"]

# Select a random word
word = random.choice(words)

# Initialize the word with underscores
word_to_guess = ["_"] * len(word)

# Initialize the number of incorrect guesses
incorrect_guesses = 0

# Set the maximum number of incorrect guesses
max_incorrect_guesses = 6

print("game starts :->")
print("\nWelcome to Hangman!")
#basic details about the game 
print("\n(hint) the guess words is fruit name")
print("\nYou have to guess a word. You have 6 chances to guess it correctly.")
game=True
while game==True:
    # Print the word with underscores
    print(" ".join(word_to_guess))

    # Ask the user for a guess
    guess = input("Enter your guess: ")
    
    # Check if the guess is correct
    if guess in word:
        # Replace the underscores with the correct guess
     for i in range(len(word)):
            if word[i] == guess:
                word_to_guess[i] = guess
                print()
    else:
        # Increment the number of incorrect guesses
        incorrect_guesses += 1
        print(f"Incorrect guess. You have {max_incorrect_guesses - incorrect_guesses} chances left.\n")

    # Check if the word has been guessed correctly
    if "_" not in word_to_guess:
        print(word)
        print("\nCongratulations, you guessed the word correctly!\n")
        game==False
        break

    # Check if the maximum number of incorrect guesses has been reached
    if incorrect_guesses >= max_incorrect_guesses:
        print(f"Sorry, you didn't guess the word correctly. The word was {word}.")
        print("\nbetter luck next time\n")
        game==False
        break
print("thank you for playing")